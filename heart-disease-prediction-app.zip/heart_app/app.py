from flask import Flask, render_template, request
import joblib
import numpy as np
import requests

app = Flask(__name__)
model = joblib.load('model_joblib_heart')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    features = [float(x) for x in request.form.values()]
    prediction = model.predict([features])[0]
    result = "Heart Disease Detected" if prediction == 1 else "No Heart Disease"

    # Data to send to Google Sheets
    data_to_send = {
        'age': features[0],
        'sex': features[1],
        'cp': features[2],
        'trestbps': features[3],
        'chol': features[4],
        'fbs': features[5],
        'restecg': features[6],
        'thalach': features[7],
        'exang': features[8],
        'oldpeak': features[9],
        'slope': features[10],
        'ca': features[11],
        'thal': features[12],
        'prediction': result
    }

    # Your Google Apps Script Web App URL
    webhook_url = 'https://script.google.com/macros/s/AKfycbxFos2yqJtiDIuNbDjwAZC--_uO0T3mY8aJZmhor0Nbp7QD7UBVfwDJOucL4lUjZXcp/exec'
    try:
        requests.post(webhook_url, json=data_to_send)
    except Exception as e:
        print(f"Error sending to Google Sheets: {e}")

    return render_template('index.html', prediction_text=result)

if __name__ == "__main__":
    app.run(debug=True)
